<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Taplist</title>
<link href="assets/css/styles.css" rel="stylesheet" type="text/css">
<!-- <link href="assets/css/high-res.css" rel="stylesheet" type="text/css"> -->
<link href="https://fonts.googleapis.com/css?family=Quicksand" rel="stylesheet">
</head>

<body>
	<h1>Choose a page:</h1>
	<h2><a href="admin.php">Admin</a></h2>
	<h2><a href="taplist.php">Taplist</a></h2>
</body>
</html>

